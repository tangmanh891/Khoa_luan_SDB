"""Kaggle T4 training script — AutoShotV2 với label smoothing.

Setup trên Kaggle (Add data):
  1. autoshotv2-src       ← ZIP source code này (thư mục Khoa_luan_SDB - Copy)
  2. autoshotv2-base      ← ckpt_0_200_0.pth (backbone pretrained)
  3. shot-dataset         ← thư mục Shot/ với 3 subfolder:
                              ads_game_videos/*.mp4   (192 video)
                              video_download/*.mp4    (486 video)
                              original_videos/*.mp4   (200 video TEST)
                            + ground_truth.txt
  4. clipshots-dataset    ← thư mục ClipShots gốc GitHub:
                              annotations/{train,test}.json
                              video_lists/{train,test}.txt
                              videos/train/*.mp4
                              videos/test/*.mp4

Chạy từ notebook cell:
    !python /kaggle/input/autoshotv2-src/scripts/kaggle_t4_train.py

Script tự động:
  1. Cài package autoshotv2 từ source
  2. Build metadata pickle từ raw Shot + ClipShots trên Kaggle
  3. Train với label smoothing (ε=0.1, asymmetric) + AMP fp16
  4. Checkpoint mỗi 5 epoch; resume được nếu Kaggle ngắt session
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

# ═══════════════════════════════════════════════════════════════════════════════
# 0.  ĐƯỜNG DẪN KAGGLE  (chỉnh slug nếu đặt tên khác khi upload)
# ═══════════════════════════════════════════════════════════════════════════════

KAGGLE_INPUT = Path("/kaggle/input")
KAGGLE_WORK  = Path("/kaggle/working")

# Source code package
SRC_DIR = next(
    (p.parent for p in KAGGLE_INPUT.rglob("pyproject.toml")
     if (p.parent / "src" / "autoshotv2").exists()),
    KAGGLE_INPUT / "autoshotv2-src",
)

# Backbone
BASE_CKPT = next(
    KAGGLE_INPUT.rglob("ckpt_0_200_0.pth"),
    KAGGLE_INPUT / "autoshotv2-base" / "ckpt_0_200_0.pth",
)

# Cấu trúc Shot dataset phẳng: 3 thư mục video + ground_truth.txt ở root
SHOT_ROOT      = next(
    (p.parent for p in KAGGLE_INPUT.rglob("ground_truth.txt")
     if (p.parent / "ads_game_videos").exists()),
    KAGGLE_INPUT / "shot-dataset",
)

# ClipShots: có annotations/ và videos/
CLIPSHOTS_ROOT = next(
    (p.parent for p in KAGGLE_INPUT.rglob("annotations/train.json")),
    KAGGLE_INPUT / "clipshots-dataset",
)

# Outputs
WORK          = KAGGLE_WORK / "autoshotv2_run"
META_OUT      = WORK / "shot_clipshots_trainval.pickle"
SAMPLE_CACHE  = WORK / "shot_clipshots_phase2_sample_cache.pkl"
OUT_CKPT      = WORK / "ckpt_phase2_shot_clipshots_best.pth"
RESULTS       = WORK / "phase2_shot_clipshots_results.pkl"
RESUME_STATE  = WORK / "checkpoints" / "phase2_resume.pt"
CKPT_DIR      = WORK / "checkpoints"
EVAL_CACHE    = WORK / "eval_cache"

WORK.mkdir(parents=True, exist_ok=True)
CKPT_DIR.mkdir(parents=True, exist_ok=True)

print(f"SRC_DIR       : {SRC_DIR}")
print(f"BASE_CKPT     : {BASE_CKPT}")
print(f"SHOT_ROOT     : {SHOT_ROOT}")
print(f"CLIPSHOTS_ROOT: {CLIPSHOTS_ROOT}")

# ═══════════════════════════════════════════════════════════════════════════════
# 1.  CÀI ĐẶT PACKAGE
# ═══════════════════════════════════════════════════════════════════════════════

print("\n── Cài package autoshotv2 ──")
subprocess.run([sys.executable, "-m", "pip", "install", "-e", str(SRC_DIR), "-q"], check=True)
print("OK")

# ═══════════════════════════════════════════════════════════════════════════════
# 2.  BUILD METADATA PICKLE
#     Shot dataset trên Kaggle có cấu trúc phẳng (khác cấu trúc cũ DatasetShot/).
#     Script prepare_shot_clipshots_trainval_flat.py xử lý đúng cấu trúc này.
# ═══════════════════════════════════════════════════════════════════════════════

# Restore previous cache/resume nếu có (từ output dataset lần trước)
PREV_KEYS = [
    "shot_clipshots_phase2_sample_cache.pkl",
    "shot_clipshots_phase2_sample_cache.pkl.partial.pkl",
    "shot_clipshots_phase2_sample_cache.pkl.parts",
    "checkpoints",
]
for name in PREV_KEYS:
    for prev in KAGGLE_INPUT.rglob(name):
        dst = WORK / name
        if not dst.exists():
            print(f"Restore từ lần trước: {prev} → {dst}")
            if prev.is_dir():
                shutil.copytree(prev, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(prev, dst)
        break

if not META_OUT.exists():
    print(f"\n── Build metadata pickle ──")
    prepare_script = SRC_DIR / "scripts" / "prepare_shot_clipshots_trainval_flat.py"
    cmd = [
        sys.executable, str(prepare_script),
        "--shot-root",       str(SHOT_ROOT),
        "--clipshots-root",  str(CLIPSHOTS_ROOT),
        "--out",             str(META_OUT),
        "--val-ratio",       "0.10",
        "--max-val-videos",  "200",
        "--seed",            "42",
    ]
    print("Command:", " ".join(cmd))
    subprocess.run(cmd, check=True)
else:
    print(f"Metadata pickle đã có: {META_OUT}")

# ═══════════════════════════════════════════════════════════════════════════════
# 3.  KIỂM TRA GPU + METADATA
# ═══════════════════════════════════════════════════════════════════════════════

import pickle
import torch

with META_OUT.open("rb") as f:
    meta = pickle.load(f)

train_keys    = list(meta.get("train_keys", []))
val_keys      = list(meta.get("val_keys", []))
shot_test_keys = list(meta.get("shot_test_entries", {}).keys())
print(f"\nMetadata: Train={len(train_keys)} | Val={len(val_keys)} | Shot-test={len(shot_test_keys)}")

print(f"\nCUDA: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    p = torch.cuda.get_device_properties(0)
    print(f"GPU: {p.name}  VRAM: {p.total_memory/1e9:.1f} GB")

# ═══════════════════════════════════════════════════════════════════════════════
# 4.  TRAINING
#
#  Hyperparams tối ưu từ focal sweep (autoshotv2v8):
#    gamma=2.0, alpha=0.6, manyhot_weight=0.3, lr=7e-6  → Shot val F1=0.6713
#
#  Mới thêm: label smoothing ε=0.1 asymmetric + AMP fp16 (T4)
#    Asymmetric: boundary frame → 0.90 (không hard-1 do uncertainty ±1-2 frame)
#                non-boundary   → 0.00 (không thêm nhiễu vào class 0)
#
#  batch-size 1024: features 1024-dim fp16 ≈ 2 MB/batch, OK với 16 GB T4
#  lr=7e-6 giữ nguyên (batch 512→1024 lý thuyết nên scale ×2, nhưng focal loss
#  với label smoothing ổn định hơn nên giữ lr cũ để tránh overshoot)
#  epochs 30 (tăng từ 20 để bù label smoothing cần thêm epoch hội tụ)
# ═══════════════════════════════════════════════════════════════════════════════

cmd = [
    sys.executable, "-m", "autoshotv2.train_phase2",
    "--meta",            str(META_OUT),
    "--base-ckpt",       str(BASE_CKPT),
    "--out-ckpt",        str(OUT_CKPT),
    "--sample-cache",    str(SAMPLE_CACHE),
    "--results",         str(RESULTS),
    "--resume-state",    str(RESUME_STATE),
    "--checkpoint-dir",  str(CKPT_DIR),
    "--eval-cache-dir",  str(EVAL_CACHE),
    # ── Hyperparams tối ưu từ sweep ──────────────────────────────────────────
    "--epochs",          "30",
    "--batch-size",      "1024",
    "--loss",            "focal",
    "--gamma",           "2.0",       # tốt nhất sweep: 2.0
    "--alpha",           "0.6",       # tốt nhất sweep: 0.6
    "--lr",              "7e-6",      # tốt nhất sweep: 7e-6
    "--weight-decay",    "1e-4",
    "--manyhot-weight",  "0.3",
    # ── Heatmap boundary labels (mới) ───────────────────────────────────────
    # Thay hard many-hot (0/1 cung) bang Gaussian mem quanh boundary frame.
    # sigma=3.0: boundary frame=1.0, ±3frame=0.61, ±6frame=0.14, ±9frame=0.01
    "--heatmap-sigma",   "3.0",
    "--heatmap-mode",    "gaussian",
    # ── Label smoothing (mới) ────────────────────────────────────────────────
    "--label-smoothing", "0.1",
    "--ls-asymmetric",
    # ── Sampling ─────────────────────────────────────────────────────────────
    "--max-samples-per-video", "160",
    "--neg-per-pos",     "3",
    "--boundary-window", "1",
    "--seed",            "42",
    "--data-seed",       "42",
    # ── T4 optimisations ─────────────────────────────────────────────────────
    "--amp",
    # ── Checkpoint / log ────────────────────────────────────────────────────
    "--save-every-epochs",  "5",
    "--log-every-batches",  "50",
    "--max-val-videos",     "200",
    "--stop-after-minutes", "530",   # dừng an toàn trước wall clock 9h Kaggle
]

print("\n── Bắt đầu training ──")
print("Command:", " ".join(cmd))
result = subprocess.run(cmd, check=False)

if result.returncode == 0:
    print(f"\nTraining hoàn thành.")
    print(f"Checkpoint: {OUT_CKPT}")
    print(f"Results:    {RESULTS}")
else:
    print(f"\nreturncode={result.returncode}")
    print("Có thể do hết time budget — lưu output dataset rồi resume bằng cách chạy lại.")

sys.exit(result.returncode)
