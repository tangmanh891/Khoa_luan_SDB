"""Build shot_clipshots_trainval.pickle từ cấu trúc Shot phẳng trên Kaggle.

Cấu trúc Shot dataset (flat — khác với DatasetShot/ có train/test subdir):
  shot_root/
  ├── ground_truth.txt         ← tất cả GT (train + test) trong 1 file
  ├── ads_game_videos/*.mp4    ← 192 video
  ├── video_download/*.mp4     ← 486 video
  └── original_videos/*.mp4    ← 200 video TEST

Cấu trúc ClipShots (gốc GitHub, không đổi):
  clipshots_root/
  ├── annotations/train.json
  ├── annotations/test.json
  ├── video_lists/train.txt
  ├── video_lists/test.txt
  └── videos/train/*.mp4
  └── videos/test/*.mp4

Ground truth format:
  31602670982.mp4 1499
  130,131
  254,255
  ...
  (dòng trống = kết thúc entry)
"""

import argparse
import json
import os
import pickle
import random
import re
from pathlib import Path
from typing import Any

import numpy as np


DEFAULT_SHOT_ROOT      = "/kaggle/input/shot-dataset"
DEFAULT_CLIPSHOTS_ROOT = "/kaggle/input/clipshots-dataset"
DEFAULT_OUT            = "/kaggle/working/autoshotv2_run/shot_clipshots_trainval.pickle"

# 3 thư mục chứa video trong Shot flat dataset
SHOT_VIDEO_SUBDIRS = ["ads_game_videos", "video_download", "original_videos"]

# original_videos/ là tập test (200 video) — dùng source_split để phân biệt
TEST_SUBDIR = "original_videos"


def find_shot_video(shot_root: Path, name: str) -> Path | None:
    """Tìm {name}.mp4 trong các thư mục con của shot_root."""
    for sub in SHOT_VIDEO_SUBDIRS:
        p = shot_root / sub / f"{name}.mp4"
        if p.exists():
            return p
    return None


def parse_ground_truth(gt_path: Path, shot_root: Path) -> tuple[dict, dict]:
    """Parse ground_truth.txt, chia train/test theo thư mục chứa video."""
    train_entries: dict[str, dict[str, Any]] = {}
    test_entries:  dict[str, dict[str, Any]] = {}

    cur_name: str | None = None
    cur_n_frames: int | None = None
    cur_transitions: list[list[int]] = []

    def flush() -> None:
        nonlocal cur_name, cur_n_frames, cur_transitions
        if cur_name is None:
            return
        video_path = find_shot_video(shot_root, cur_name)
        if video_path is None:
            return

        # Phân biệt train / test theo thư mục chứa video
        is_test = (video_path.parent.name == TEST_SUBDIR)
        split   = "shot_test" if is_test else "shot_train"
        key     = f"{split}:{cur_name}"

        entry: dict[str, Any] = {
            "dataset":      "shot",
            "source_split": split,
            "source_name":  cur_name,
            "video_path":   str(video_path),
            "transitions":  np.asarray(cur_transitions, dtype=np.int32),
            "n_frames":     cur_n_frames,
        }
        if is_test:
            test_entries[key] = entry
        else:
            train_entries[key] = entry

    with gt_path.open(encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                flush()
                cur_name = None
                cur_n_frames = None
                cur_transitions = []
                continue

            if ".mp4" in line:
                flush()
                cur_name = None
                cur_n_frames = None
                cur_transitions = []
                parts = line.split()
                m = re.match(r"^(.+)\.mp4$", parts[0])
                if m is None:
                    continue
                cur_name = m.group(1)
                if len(parts) >= 2:
                    try:
                        cur_n_frames = int(float(parts[1]))
                    except ValueError:
                        pass
                continue

            if cur_name is None:
                continue
            try:
                start, end = map(int, line.split(","))
                cur_transitions.append([start, end])
            except ValueError:
                continue

    flush()
    return train_entries, test_entries


def load_clipshots_split(clipshots_root: Path, split: str) -> dict[str, dict[str, Any]]:
    ann_path   = clipshots_root / "annotations" / f"{split}.json"
    list_path  = clipshots_root / "video_lists"  / f"{split}.txt"
    video_dir  = clipshots_root / "videos" / split

    with ann_path.open(encoding="utf-8") as f:
        annotations = json.load(f)
    with list_path.open(encoding="utf-8") as f:
        listed = [line.strip() for line in f if line.strip()]

    entries: dict[str, dict[str, Any]] = {}
    for filename in listed:
        ann = annotations.get(filename)
        if ann is None:
            continue
        video_path = video_dir / filename
        if not video_path.exists():
            continue
        stem = filename[:-4] if filename.endswith(".mp4") else filename
        key  = f"clipshots_{split}:{stem}"
        entries[key] = {
            "dataset":      "clipshots",
            "source_split": split,
            "source_name":  stem,
            "video_path":   str(video_path),
            "transitions":  np.asarray(ann.get("transitions", []), dtype=np.int32),
            "n_frames":     int(float(ann["frame_num"])) if ann.get("frame_num") else None,
        }
    return entries


def split_keys(
    entries: dict[str, dict[str, Any]],
    val_ratio: float,
    max_val_videos: int,
    seed: int,
) -> tuple[list[str], list[str]]:
    rng = random.Random(seed)
    train_keys: list[str] = []
    val_keys:   list[str] = []

    groups: dict[str, list[str]] = {}
    for key, entry in entries.items():
        g = f"{entry['dataset']}:{entry['source_split']}"
        groups.setdefault(g, []).append(key)

    for group_keys in groups.values():
        group_keys = sorted(group_keys)
        rng.shuffle(group_keys)
        n_val = max(1, round(len(group_keys) * val_ratio)) if len(group_keys) > 1 else 0
        val_keys.extend(group_keys[:n_val])
        train_keys.extend(group_keys[n_val:])

    if max_val_videos > 0 and len(val_keys) > max_val_videos:
        val_keys = sorted(val_keys)
        rng.shuffle(val_keys)
        keep = set(val_keys[:max_val_videos])
        train_keys.extend(k for k in val_keys if k not in keep)
        val_keys = list(keep)

    return sorted(train_keys), sorted(val_keys)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shot-root",       default=DEFAULT_SHOT_ROOT)
    parser.add_argument("--clipshots-root",  default=DEFAULT_CLIPSHOTS_ROOT)
    parser.add_argument("--out",             default=DEFAULT_OUT)
    parser.add_argument("--val-ratio",       type=float, default=0.10)
    parser.add_argument("--max-val-videos",  type=int,   default=200)
    parser.add_argument("--seed",            type=int,   default=42)
    # GT goc AutoShot: loai 200 video nay ra khoi train de eval fair
    parser.add_argument("--official-gt",     default=None,
                        help="Path to gt_scenes_dict_baseline_v2.pickle. "
                             "Videos in this dict are excluded from training and used as official test set.")
    args = parser.parse_args()

    shot_root      = Path(args.shot_root)
    clipshots_root = Path(args.clipshots_root)
    gt_path        = shot_root / "ground_truth.txt"

    print(f"Shot root     : {shot_root}")
    print(f"ClipShots root: {clipshots_root}")
    print(f"Ground truth  : {gt_path}")

    # ── Load official GT test names (neu co) ─────────────────────────────────
    official_test_names: set[str] = set()
    if args.official_gt:
        with open(args.official_gt, "rb") as f:
            official_gt_dict = pickle.load(f)
        official_test_names = set(official_gt_dict.keys())
        print(f"Official GT test videos: {len(official_test_names)} (se loai khoi train)")

    # ── Parse Shot ───────────────────────────────────────────────────────────
    shot_train, shot_test = parse_ground_truth(gt_path, shot_root)

    # Chuyen cac video official test tu shot_train -> official_test_entries
    official_test_entries: dict[str, dict[str, Any]] = {}
    if official_test_names:
        to_move = [k for k, v in shot_train.items()
                   if v["source_name"] in official_test_names]
        for k in to_move:
            official_test_entries[k] = shot_train.pop(k)
        print(f"Shot train entries (sau khi loai official test): {len(shot_train)}")
        print(f"Official test entries (tu shot_train): {len(official_test_entries)}")
    else:
        print(f"Shot train entries: {len(shot_train)}")
    print(f"Shot test  entries (original_videos): {len(shot_test)}")

    # ── Parse ClipShots ──────────────────────────────────────────────────────
    clip_train = load_clipshots_split(clipshots_root, "train")
    clip_test  = load_clipshots_split(clipshots_root, "test")
    print(f"ClipShots train: {len(clip_train)}")
    print(f"ClipShots test : {len(clip_test)}  (excluded from training)")

    # ── Combine train pool: Shot train + ClipShots train ─────────────────────
    entries: dict[str, dict[str, Any]] = {}
    entries.update(shot_train)
    entries.update(clip_train)

    # ── Train / val split ────────────────────────────────────────────────────
    train_keys, val_keys = split_keys(
        entries,
        val_ratio=args.val_ratio,
        max_val_videos=args.max_val_videos,
        seed=args.seed,
    )

    n_trans_train = int(sum(len(entries[k]["transitions"]) for k in train_keys))
    n_trans_val   = int(sum(len(entries[k]["transitions"]) for k in val_keys))

    print(f"\nTrain videos       : {len(train_keys)}  ({n_trans_train} transitions)")
    print(f"Val   videos       : {len(val_keys)}  ({n_trans_val} transitions)")
    print(f"Shot test (original_videos): {len(shot_test)}")
    print(f"Official test (GT goc)     : {len(official_test_entries)}")

    payload = {
        "entries":                   entries,
        "train_keys":                train_keys,
        "val_keys":                  val_keys,
        "shot_test_entries":         shot_test,
        "official_test_entries":     official_test_entries,
        "excluded_clipshots_test_count": len(clip_test),
        "config": {
            "shot_root":       str(shot_root.resolve()),
            "clipshots_root":  str(clipshots_root.resolve()),
            "val_ratio":       args.val_ratio,
            "max_val_videos":  args.max_val_videos,
            "seed":            args.seed,
            "official_gt":     args.official_gt,
        },
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("wb") as f:
        pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
    print(f"\nSaved → {out}")


if __name__ == "__main__":
    main()
