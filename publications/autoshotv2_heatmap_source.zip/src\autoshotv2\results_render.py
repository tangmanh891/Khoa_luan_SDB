"""Render the consolidated experiment manifest into publication outputs."""

from __future__ import annotations

import json
from typing import Any

from autoshotv2.results_manifest import ABLATION_ORDER, DATASET_LABELS, DATASET_ORDER


def f4(value: float | None) -> str:
    return "-" if value is None else f"{value:.4f}"


def f3(value: float | None) -> str:
    return "-" if value is None else f"{value:.3f}"


def experiment_map(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {item["id"]: item for item in manifest["experiments"]}


def comparison_map(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {item["id"]: item for item in manifest["comparison_models"]}


def render_markdown(manifest: dict[str, Any]) -> str:
    lines = [
        "# Bảng Tổng Hợp Kết Quả Thực Nghiệm AutoShotV2",
        "",
        "File này được sinh từ `reports/experimental_results.json` bằng",
        "`python scripts/sync_experimental_results.py --write`. Không sửa trực tiếp.",
        "",
        "Các nhóm dùng protocol khác nhau; chỉ so sánh trực tiếp trong cùng nhóm.",
        "",
        "## Bảng Tất Cả Thực Nghiệm",
        "",
        "| Nhóm | Thực nghiệm / protocol | SHOT | BBC | ClipShots | Ghi chú |",
        "|---|---|---:|---:|---:|---|",
    ]
    for item in manifest["experiments"]:
        metrics = item["metrics"]
        lines.append(
            "| {group} | `{identifier}` - {label} | {shot} | {bbc} | {clip} | {note} |".format(
                group=item["group"],
                identifier=item["id"],
                label=item["label"],
                shot=f4(metrics["shot"]["f1"]),
                bbc=f4(metrics["bbc"]["f1"]),
                clip=f4(metrics["clipshots"]["f1"]),
                note=item["note"].replace("|", "\\|"),
            )
        )

    by_id = experiment_map(manifest)
    lines += [
        "",
        "## Kết Quả Checkpoint Deploy",
        "",
        "| Dataset | Chế độ | Threshold | F1 | Precision | Recall | TP | FP | FN |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for experiment_id in ("phase2_deploy_threshold", "phase2_best_sweep"):
        item = by_id[experiment_id]
        for dataset in DATASET_ORDER:
            metric = item["metrics"][dataset]
            lines.append(
                f"| {DATASET_LABELS[dataset]} | {item['protocol']} | "
                f"{f4(metric.get('threshold'))} | {f4(metric['f1'])} | "
                f"{f4(metric['precision'])} | {f4(metric['recall'])} | "
                f"{metric['tp']} | {metric['fp']} | {metric['fn']} |"
            )

    lines += [
        "",
        "## Nguồn Và Mức Tái Lập",
        "",
        "- `result_json`: tái lập ở mức đọc lại JSON đã chốt hoặc chạy lại từ checkpoint/dataset.",
        "- `logits`: có thể tính lại metric từ logits và ground truth khi artifact tương ứng có sẵn.",
        "- `literature` và `legacy_result`: chỉ dùng trong bảng so sánh, không được coi là run mới.",
        "",
    ]
    return "\n".join(lines)


def tex_escape(value: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
    }
    return "".join(replacements.get(char, char) for char in value)


def tex_value(value: float | None, bold: bool = False) -> str:
    rendered = "--" if value is None else f"{value:.4f}"
    return rf"\textbf{{{rendered}}}" if bold else rendered


def render_tex_macros(manifest: dict[str, Any]) -> str:
    experiments = experiment_map(manifest)
    comparisons = comparison_map(manifest)
    deploy = experiments["phase2_deploy_threshold"]["metrics"]
    deploy_threshold = experiments["phase2_deploy_threshold"]["metrics"]
    best = comparisons["autoshotv2_best_sweep"]["metrics"]
    a0 = experiments["A0_autoshot_original"]["metrics"]
    b4 = experiments["B4_temperature_gaussian"]["metrics"]
    transnet = comparisons["transnetv2_reported"]["metrics"]
    definitions = {
        "ASVTwoShotFOne": f4(deploy["shot"]["f1"]),
        "ASVTwoBBCFOne": f4(deploy["bbc"]["f1"]),
        "ASVTwoClipFOne": f4(deploy["clipshots"]["f1"]),
        "ASVTwoClipDeployFOne": f4(deploy_threshold["clipshots"]["f1"]),
        "ASVTwoBestShotFOne": f4(best["shot"]),
        "ASVTwoBestBBCFOne": f4(best["bbc"]),
        "ASVTwoBestClipFOne": f4(best["clipshots"]),
        "ASVTwoShotPrecision": f4(deploy["shot"]["precision"]),
        "ASVTwoShotRecall": f4(deploy["shot"]["recall"]),
        "AutoShotOriginalShotFOne": f4(a0["shot"]["f1"]),
        "BFourShotFOne": f4(b4["shot"]["f1"]),
        "BFourBBCFOne": f4(b4["bbc"]["f1"]),
        "BFourClipFOne": f4(b4["clipshots"]["f1"]),
        "TransNetShotFOne": f4(transnet["shot"]),
        "ASVTwoVsTransNetShotPP": f"{(deploy['shot']['f1'] - transnet['shot']) * 100:.1f}",
        "ASVTwoVsAutoShotShotPP": f"{(deploy['shot']['f1'] - a0['shot']['f1']) * 100:.1f}",
        "ASVTwoBestVsTransNetShotPP": f"{(best['shot'] - transnet['shot']) * 100:.2f}",
        "ASVTwoBestVsAutoShotShotPP": f"{(best['shot'] - a0['shot']['f1']) * 100:.2f}",
        "ASVTwoBestVsAutoShotClipPP": f"{(best['clipshots'] - a0['clipshots']['f1']) * 100:.2f}",
    }
    lines = [
        "% Generated by scripts/sync_experimental_results.py. Do not edit.",
    ]
    lines.extend(rf"\newcommand{{\{name}}}{{{value}}}" for name, value in definitions.items())
    lines.append("")
    return "\n".join(lines)


def render_tex_tables(manifest: dict[str, Any]) -> str:
    comparisons = comparison_map(manifest)
    experiments = experiment_map(manifest)
    lines = ["% Generated by scripts/sync_experimental_results.py. Do not edit.", ""]

    overview_rows = [
        "Checkpoint triển khai chính & "
        rf"\textbf{{{f4(experiments['phase2_deploy_threshold']['metrics']['shot']['f1'])}}} & "
        rf"\textbf{{{f4(experiments['phase2_deploy_threshold']['metrics']['bbc']['f1'])}}} & "
        f"{f4(experiments['phase2_deploy_threshold']['metrics']['clipshots']['f1'])} & "
        "AutoShotV2 triển khai ở ngưỡng cố định. \\\\",
        "Ablation Pha 2 tốt nhất (B4) & "
        f"{f4(experiments['B4_temperature_gaussian']['metrics']['shot']['f1'])} & "
        f"{f4(experiments['B4_temperature_gaussian']['metrics']['bbc']['f1'])} & "
        f"{f4(experiments['B4_temperature_gaussian']['metrics']['clipshots']['f1'])} & "
        "Temperature + Gaussian, không cần huấn luyện lại. \\\\",
        "Hiệu chỉnh hậu xử lý CV & "
        f"{f4(experiments['calibration_cv_A1_phase2_control']['metrics']['shot']['f1'])} & "
        f"{f4(experiments['calibration_cv_A1_phase2_control']['metrics']['bbc']['f1'])} & "
        rf"\textbf{{{f4(experiments['calibration_cv_A0_autoshot_baseline']['metrics']['clipshots']['f1'])}}} & "
        "A1 tốt nhất trên SHOT/BBC, A0 tốt nhất trên ClipShots. \\\\",
    ]
    lines += [r"\newcommand{\ExperimentOverviewRows}{%", *overview_rows, "}", ""]

    comparison_order = (
        "dsm_reported",
        "transnet_reported",
        "transnetv2_reported",
        "transnetv2_reproduced",
        "autoshot_reported",
        "autoshot_reproduced_legacy",
        "autoshotv2_deploy",
        "autoshotv2_best_sweep",
    )
    MODEL_NAMES_MAPPING = {
        "dsm_reported": "Deep Structured Models",
        "transnet_reported": "TransNet V1",
        "transnetv2_reported": "TransNetV2",
        "transnetv2_reproduced": "TransNetV2",
        "autoshot_reported": "AutoShot",
        "autoshot_reproduced_legacy": "AutoShot",
        "autoshotv2_deploy": "AutoShotV2",
        "autoshotv2_best_sweep": "AutoShotV2",
    }
    EVALUATION_PROCESS_LABELS = {
        "dsm_reported": "Theo báo cáo",
        "transnet_reported": "Theo báo cáo",
        "transnetv2_reported": "Theo báo cáo",
        "transnetv2_reproduced": "Tái lập",
        "autoshot_reported": "Theo báo cáo",
        "autoshot_reproduced_legacy": "Tái lập",
        "autoshotv2_deploy": "Triển khai cố định (ngưỡng 0.10)",
        "autoshotv2_best_sweep": "Mức trần lạc quan (oracle)",
    }
    rows = []
    for identifier in comparison_order:
        item = comparisons[identifier]
        name = MODEL_NAMES_MAPPING.get(identifier, item["name"])
        process = EVALUATION_PROCESS_LABELS.get(identifier, "")
        metrics = item["metrics"]
        rows.append(
            f"{tex_escape(name)} & {tex_escape(process)} & "
            f"{tex_value(metrics['shot'], identifier in ('autoshotv2_deploy', 'autoshotv2_best_sweep'))} & "
            f"{tex_value(metrics['bbc'], identifier in ('autoshotv2_deploy', 'autoshotv2_best_sweep'))} & "
            f"{tex_value(metrics['clipshots'], identifier == 'autoshotv2_best_sweep')} \\\\"
        )
    lines += [r"\newcommand{\MainComparisonRows}{%", *rows, "}", ""]

    deploy = experiments["phase2_deploy_threshold"]["metrics"]
    rows = []
    for dataset in ("shot", "clipshots", "bbc"):
        metric = deploy[dataset]
        rows.append(
            f"{DATASET_LABELS[dataset]} & {metric['threshold']:.2f} & "
            f"{metric['precision']:.4f} & {metric['recall']:.4f} & "
            f"{tex_value(metric['f1'], dataset in {'shot', 'bbc'})} & "
            f"{metric['tp']} & {metric['fp']} & {metric['fn']} \\\\"
        )
    lines += [r"\newcommand{\DeployPRFRows}{%", *rows, "}", ""]

    a1_metrics = experiments["A1_phase2_bce_onehot"]["metrics"]
    rows = []
    for identifier in ABLATION_ORDER:
        if identifier in {"A0_autoshot_original", "A1_phase2_bce_onehot"}:
            continue
        item = experiments[identifier]
        metrics = item["metrics"]
        selected = identifier == "B4_temperature_gaussian"
        label = item["label"]
        if selected:
            label += " (được chọn)"
        cells = []
        for dataset in DATASET_ORDER:
            delta = metrics[dataset]["f1"] - a1_metrics[dataset]["f1"]
            rendered = f"{delta * 100:+.2f}"
            cells.append(rf"\textbf{{{rendered}}}" if selected else rendered)
        rows.append(
            f"{tex_escape(label)} & {cells[0]} & {cells[1]} & {cells[2]} \\\\"
        )
    lines += [r"\newcommand{\AblationRows}{%", *rows, "}", ""]

    calibration_rows = []
    for identifier in (
        "calibration_cv_A0_autoshot_baseline",
        "calibration_cv_A1_phase2_control",
        "calibration_cv_B5_phase2_full",
    ):
        item = experiments[identifier]
        metrics = item["metrics"]
        calibration_rows.append(
            f"{tex_escape(item['label'].replace(', 5-fold CV', ''))} & "
            f"{tex_value(metrics['shot']['f1'], identifier.endswith('A1_phase2_control'))} & "
            f"{tex_value(metrics['bbc']['f1'], identifier.endswith('A1_phase2_control'))} & "
            f"{tex_value(metrics['clipshots']['f1'], identifier.endswith('A0_autoshot_baseline'))} \\\\"
        )
    lines += [r"\newcommand{\CalibrationCVRows}{%", *calibration_rows, "}", ""]

    shot = comparisons
    lines += [
        r"\newcommand{\AppendixShotRows}{%",
        "SHOT tập kiểm tra & "
        f"{f4(shot['transnetv2_reported']['metrics']['shot'])} & "
        f"{f4(experiments['A0_autoshot_original']['metrics']['shot']['f1'])} & "
        rf"\textbf{{{f4(experiments['phase2_best_sweep']['metrics']['shot']['f1'])}}} \\",
        "}",
        "",
        r"\newcommand{\AppendixClipshotsRows}{%",
        "ClipShots (theo báo cáo) & "
        f"{f4(shot['transnetv2_reported']['metrics']['clipshots'])} & "
        rf"\textbf{{{f4(shot['autoshot_reported']['metrics']['clipshots'])}}} & "
        f"{f4(experiments['phase2_best_sweep']['metrics']['clipshots']['f1'])} \\\\",
        "ClipShots (tự chạy lại) & "
        f"{f4(shot['transnetv2_reproduced']['metrics']['clipshots'])} & "
        f"{f4(shot['autoshot_reproduced_legacy']['metrics']['clipshots'])} & "
        f"{f4(experiments['phase2_best_sweep']['metrics']['clipshots']['f1'])} \\\\",
        "}",
        "",
    ]

    rows = []
    for item in manifest["experiments"]:
        metrics = item["metrics"]
        rows.append(
            f"{tex_escape(item['group'])} & {tex_escape(item['label'])} & "
            f"{f4(metrics['shot']['f1'])} & {f4(metrics['bbc']['f1'])} & "
            f"{f4(metrics['clipshots']['f1'])} & {tex_escape(item['note'])} \\\\"
        )
    lines += [r"\newcommand{\AllExperimentsRows}{%", *rows, "}", ""]
    return "\n".join(lines)


def render_slide_data(manifest: dict[str, Any]) -> str:
    experiments = experiment_map(manifest)
    comparisons = comparison_map(manifest)
    deploy = experiments["phase2_best_sweep"]["metrics"]
    a0 = experiments["A0_autoshot_original"]["metrics"]
    data = {
        "schema_version": 1,
        "comparison_models": manifest["comparison_models"],
        "deploy": deploy,
        "ablation": [
            {
                "id": identifier,
                "label": experiments[identifier]["label"],
                "metrics": experiments[identifier]["metrics"],
            }
            for identifier in ABLATION_ORDER
        ],
        "summary": {
            "shot_f1": deploy["shot"]["f1"],
            "bbc_f1": deploy["bbc"]["f1"],
            "clipshots_f1": deploy["clipshots"]["f1"],
            "shot_delta_vs_transnet_pp": (
                deploy["shot"]["f1"] - comparisons["transnetv2_reported"]["metrics"]["shot"]
            )
            * 100,
            "shot_delta_vs_autoshot_pp": (
                deploy["shot"]["f1"] - a0["shot"]["f1"]
            )
            * 100,
        },
    }
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def render_paper_tex_macros(manifest: dict[str, Any]) -> str:
    experiments = experiment_map(manifest)
    comparisons = comparison_map(manifest)
    b4 = experiments["B4_temperature_gaussian"]["metrics"]
    a1 = experiments["A1_phase2_bce_onehot"]["metrics"]
    deploy = experiments["phase2_deploy_threshold"]["metrics"]
    best = comparisons["autoshotv2_best_sweep"]["metrics"]
    deployment = manifest["deployment_config"]
    autoshot = comparisons["autoshot_reproduced_legacy"]["metrics"]
    transnet = comparisons["transnetv2_reported"]["metrics"]
    analysis = manifest["supplemental_results"]["paper_analysis"]
    protocol = analysis["protocol"]
    definitions = {
        # Two operating points coexist: the deployed checkpoint (fixed-deployment analysis)
        # and the controlled B4 replication (ablation/seed-study track).
        "PaperDeployTemperature": f"{deployment['temperature']:.4f}",
        "PaperBFourTemperature": f"{protocol['temperature']:.4f}",
        "PaperGaussianSigma": f"{protocol['sigma']:.1f}",
        "PaperDeployThreshold": f"{protocol['threshold']:.2f}",
        "PaperMatchTolerance": str(protocol["matching_tolerance_frames"]),
        "PaperDeployShotFOne": f4(deploy["shot"]["f1"]),
        "PaperDeployBBCFOne": f4(deploy["bbc"]["f1"]),
        "PaperDeployClipFOne": f4(deploy["clipshots"]["f1"]),
        "PaperBestClipFOne": f4(best["clipshots"]),
        "PaperDeployShotPrecision": f4(deploy["shot"]["precision"]),
        "PaperDeployShotRecall": f4(deploy["shot"]["recall"]),
        "PaperDeployClipPrecision": f4(deploy["clipshots"]["precision"]),
        "PaperDeployClipRecall": f4(deploy["clipshots"]["recall"]),
        "PaperDeployVsAutoShotPP": f"{(deploy['shot']['f1'] - autoshot['shot']) * 100:.2f}",
        "PaperDeployVsTransNetPP": f"{(deploy['shot']['f1'] - transnet['shot']) * 100:.2f}",
        "PaperBFourVsAOneShotPP": f"{(b4['shot']['f1'] - a1['shot']['f1']) * 100:.2f}",
        "PaperBFourVsAOneBBCPP": f"{(b4['bbc']['f1'] - a1['bbc']['f1']) * 100:.2f}",
        "PaperBFourVsAOneClipPP": f"{(b4['clipshots']['f1'] - a1['clipshots']['f1']) * 100:.2f}",
        "PaperAutoShotShotFOne": f4(autoshot["shot"]),
        "PaperTransNetShotFOne": f4(transnet["shot"]),
        "PaperBestShotFOne": f4(best["shot"]),
        "PaperBestVsAutoShotPP": f"{(best['shot'] - autoshot['shot']) * 100:.2f}",
        "PaperBestVsTransNetPP": f"{(best['shot'] - transnet['shot']) * 100:.2f}",
    }
    seed_study = manifest["supplemental_results"]["journal_seed_study"]
    definitions["PaperSeedCount"] = str(len(seed_study["training_seeds"]))
    for dataset, short in (("shot", "Shot"), ("bbc", "BBC"), ("clipshots", "Clip")):
        block = seed_study["datasets"][dataset]
        # Rendered as percentage points to match the paper's delta convention.
        definitions[f"PaperSeed{short}FOneStd"] = f"{block['sample_std']['f1'] * 100:.2f}"
    lines = ["% Generated by scripts/sync_experimental_results.py. Do not edit."]
    lines.extend(rf"\newcommand{{\{name}}}{{{value}}}" for name, value in definitions.items())
    lines.append("")
    return "\n".join(lines)


def paper_metric(value: float | None, bold: bool = False) -> str:
    rendered = "--" if value is None else f"{value:.4f}"
    return rf"\textbf{{{rendered}}}" if bold else rendered


def render_paper_tex_tables(manifest: dict[str, Any]) -> str:
    experiments = experiment_map(manifest)
    comparisons = comparison_map(manifest)
    analysis = manifest["supplemental_results"]["paper_analysis"]
    lines = ["% Generated by scripts/sync_experimental_results.py. Do not edit.", ""]

    comparison_rows = []
    comparison_definitions = (
        ("dsm_reported", "Deep Structured Models (DSM)"),
        ("transnet_reported", "TransNet (V1)"),
        ("transnetv2_reproduced", "TransNetV2, reproduced"),
        ("autoshot_reproduced_legacy", "AutoShot, reproduced"),
    )
    for identifier, label in comparison_definitions:
        metrics = comparisons[identifier]["metrics"]
        bold_clip = False
        comparison_rows.append(
            f"{label} & {paper_metric(metrics['shot'])} & "
            f"{paper_metric(metrics['bbc'])} & {paper_metric(metrics['clipshots'], bold_clip)} \\\\"
        )

    deploy = comparisons["autoshotv2_deploy"]["metrics"]
    best_sweep = comparisons["autoshotv2_best_sweep"]["metrics"]
    comparison_rows += [
        "AutoShotV2 (ours), fixed deployment & "
        f"{paper_metric(deploy['shot'])} & "
        f"{paper_metric(deploy['bbc'], True)} & "
        f"{paper_metric(deploy['clipshots'])} " r"\\",
        "AutoShotV2 (ours), per-dataset best$^{\\dagger}$ & "
        f"{paper_metric(best_sweep['shot'], True)} & "
        f"{paper_metric(best_sweep['bbc'], True)} & "
        f"{paper_metric(best_sweep['clipshots'], True)} \\\\",
    ]
    lines += [r"\newcommand{\PaperMainResultRows}{%", *comparison_rows, "}", ""]

    calibration = analysis["calibration"]
    calibration_metric_rows = []
    for key, label in (
        ("before", "Before temperature scaling"),
        ("after_temperature", "After temperature scaling"),
    ):
        metric = calibration[key]
        calibration_metric_rows.append(
            f"{label} & {metric['nll']:.6f} & {metric['brier']:.6f} & "
            f"{metric['ece']:.6f} & {metric['adaptive_ece']:.6f} & "
            f"{metric['class_balanced_ece']:.6f} \\\\"
        )
    lines += [
        r"\newcommand{\PaperCalibrationMetricRows}{%",
        *calibration_metric_rows,
        "}",
        "",
    ]

    paired_rows = []
    # Increase/decrease quantities are rendered as percentage points (pp).
    for dataset in DATASET_ORDER:
        metric = analysis["paired_delta_vs_a1"][dataset]
        paired_rows.append(
            f"{DATASET_LABELS[dataset]} & {metric['delta'] * 100:+.2f} & "
            f"[{metric['ci95_low'] * 100:+.2f}, {metric['ci95_high'] * 100:+.2f}] & "
            f"{'Yes' if metric['excludes_zero'] else 'No'} \\\\"
        )
    lines += [r"\newcommand{\PaperPairedDeltaRows}{%", *paired_rows, "}", ""]

    test_calibration_rows = []
    for dataset in DATASET_ORDER:
        metric = analysis["test_calibration"][dataset]["after_temperature"]
        test_calibration_rows.append(
            f"{DATASET_LABELS[dataset]} & {metric['nll']:.6f} & "
            f"{metric['brier']:.6f} & {metric['ece']:.6f} & "
            f"{metric['adaptive_ece']:.6f} & "
            f"{metric['class_balanced_ece']:.6f} \\\\"
        )
    lines += [
        r"\newcommand{\PaperTestCalibrationRows}{%",
        *test_calibration_rows,
        "}",
        "",
    ]

    efficiency = analysis["efficiency"]
    benchmark = efficiency["postprocess_benchmark"]
    efficiency_rows = [
        f"Frozen backbone parameters & {efficiency['frozen_backbone_parameters']:,} \\\\",
        f"Trainable Phase 2 head parameters & {efficiency['trainable_head_parameters']:,} \\\\",
        f"Deployed primary-path parameters & {efficiency['deployed_primary_path_parameters']:,} \\\\",
        f"Training videos / sampled frames & {efficiency['training_videos']} / "
        f"{efficiency['training_samples']:,} \\\\",
        f"Training epochs / seed & {efficiency['epochs']} / {efficiency['training_seed']} \\\\",
        "Post-process CPU cost & "
        f"{benchmark['milliseconds_per_million_frames']:.1f} ms / $10^6$ frames \\\\",
    ]
    lines += [r"\newcommand{\PaperEfficiencyRows}{%", *efficiency_rows, "}", ""]

    paper_ablation_labels = {
        "A0_autoshot_original": "A0 -- AutoShot baseline",
        "A1_phase2_bce_onehot": "A1 -- BCE + one-hot",
        "A2_focal_only": "A2 -- Focal only",
        "A3_manyhot_only": "A3 -- Many-hot only",
        "P1_gaussian_only": "P1 -- Gaussian only",
        "P2_temperature_only": "P2 -- Temperature only",
        "B1_focal_manyhot": "B1 -- Focal + many-hot",
        "B4_temperature_gaussian": "B4 -- Temperature + Gaussian",
        "B5_full_candidate": "B5 -- Full candidate",
    }
    # The replication's component analysis is reported as deltas against the
    # A1 control only: its absolute scores come from a separate training run
    # and would otherwise compete with the primary fixed-deployment checkpoint.
    a1_metrics = experiments["A1_phase2_bce_onehot"]["metrics"]
    delta_rows = []
    for identifier in ABLATION_ORDER:
        if identifier in {"A0_autoshot_original", "A1_phase2_bce_onehot"}:
            continue
        metrics = experiments[identifier]["metrics"]
        selected = identifier == "B4_temperature_gaussian"
        label = paper_ablation_labels[identifier]
        if selected:
            label += " (selected)"
        cells = []
        for dataset in DATASET_ORDER:
            delta = metrics[dataset]["f1"] - a1_metrics[dataset]["f1"]
            rendered = f"{delta * 100:+.2f}"
            cells.append(rf"\textbf{{{rendered}}}" if selected else rendered)
        delta_rows.append(f"{tex_escape(label)} & {cells[0]} & {cells[1]} & {cells[2]} \\\\")
    lines += [r"\newcommand{\PaperAblationDeltaRows}{%", *delta_rows, "}", ""]

    breakdown = manifest["supplemental_results"]["clipshots_transition_breakdown"]
    breakdown_rows = []
    for item in breakdown["transition_types"]:
        breakdown_rows.append(
            f"{tex_escape(item['label'])} & {item['ground_truth']} & "
            f"{item['matched']} & {item['missed']} & {item['recall']:.4f} \\\\"
        )
    lines += [r"\newcommand{\PaperClipBreakdownRows}{%", *breakdown_rows, "}", ""]
    return "\n".join(lines)
